package rest;
/*
Application: LifeWay Rest Service
Version: 1.0
Date: 2020/09/30
Author: Joseph Kopnicky

Software Packages Used:
	Eclipse IDE for Java EE - Version 2020-09 (4.17.0)
	Jersey - Version 2.31
	Apache Tomcat - Version 8.5.58
	Postman - v7.33.1 (for testing post)
	
Coding Challenge for Software Engineer Applicants:
1.	Create a REST service with a single endpoint that accepts a json message 
	with two fields.."id" and "message". (example: { "id": "123", "message": "hello world" })
2.	The endpoint should return a json document with a single field "count" that contains the total number of words 
	contained in all the messages received to that point.
	a.	For example, if the first message contains 3 words it would respond with count = 3. 
		If the next message contains 5 words it would respond with count = 8.
3.	The service should ignore messages with duplicate ids. (i.e. ids that have already been processed)
4.	Use the programming language of your choice.
5.	Upload all code to a public github repo with a readme that explains how to build and run the project
*/

//Imports
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.json.*;

import java.io.StringReader;
import java.lang.String;
import java.util.ArrayList;


//Start of Application
//Full URI when used on local machine w/ Tomcat set to local port 8080: http://localhost:8080/LifeWay_REST_Service/rest/main
@Path("/main")
public class Main {
	
	static ArrayList<Message> messageList = new ArrayList<Message>(); //Array list of message objects
	int totalCount; //Total Count of Words
	
	//HTTP Post method, consuming and producing JSON
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
	public JsonObject messageJSON(String jsonMessage)
	{
		int found = 0; //flag for determining if message already exists
		
		//JSON Message handling to create a Json object to pull out info by name / element
		JsonReader reader = Json.createReader(new StringReader(jsonMessage)); 
		JsonObject jsonObject = reader.readObject();
		
		//create new message object from Json Message
		Message m = new Message();
		m.setMessage(Integer.parseInt(jsonObject.getString("id")), jsonObject.getString("message"));
		
	
		if(messageList.isEmpty()) {
			//If message list is empty then add first message
			messageList.add(m);
		}
		else{
			//Search for message by id
			System.out.println("Inside Else");
			for(int i = 0; i < messageList.size(); i++){
				//Iterate through message list to see if ID exists
				
				if( messageList.get(i).getId() == m.getId()) {
					//If message found set flag
					found = 1;
				}
			}
		}
		
		if(found == 0) {
			//If flag is not set then message id was not found, add new message
			messageList.add(m);	
		}
		
		
		for(int j = 0; j < messageList.size(); j++){
			//Iterate through message list to count up word counts
			totalCount = totalCount + messageList.get(j).getCount();
		}
		
		//return a Json object
    	JsonObject countJson = Json.createObjectBuilder().add("count", totalCount).add("Message", jsonMessage).build();
      	return countJson;
	}
}
