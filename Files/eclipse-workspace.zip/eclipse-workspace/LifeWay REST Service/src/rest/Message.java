package rest;
/*
 Message Class
 Message has two fields ID and Message
 Return Count of words in Message  
 */
public class Message {

	private int messageId;
	private String messageString;
	private int wordCount = 0;
	
	public void setMessage(int id, String message) {
		
		this.messageId = id;
		this.messageString = message;
		this.wordCount = wordCounter(messageString);
	}
	
	public int getId() {
		
		return this.messageId;
	}
	
	public String getMessage() {
		
		return this.messageString;
	}
	
	public int getCount() {
		
		return this.wordCount;
	}
	
	private int wordCounter(String message) {
		//simple word counter in a string
		int count = 0;
		
		//detect null
		if(message == null) 
		{
			return count = 0;
		}
		//remove white space on ends of string
		message.trim();
		
		//anything left after trimming?
		if(message.equals(""))
		{
			return count = 0;
		}
		
		for(int i = 0; i < message.length(); i++) {
			
			if(message.charAt(i) == ' ') {
				count++;
			}
			
		}		
		
		return count + 1;
	}
	
}
