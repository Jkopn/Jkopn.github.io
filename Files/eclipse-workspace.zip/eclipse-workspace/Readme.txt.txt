Rest API
Using Java and Json
Tested with TomCat Version 8.5
Application: LifeWay Rest Service
Version: 1.0
Date: 2020/09/30
Author: Joseph Kopnicky

Software Packages Used:
	Eclipse IDE for Java EE - Version 2020-09 (4.17.0)
		https://www.eclipse.org/downloads/
	Jersey - Version 2.31 (its 2.1 bundle on website)
		https://eclipse-ee4j.github.io/jersey/download.html
	Apache Tomcat - Version 8.5.58
		https://tomcat.apache.org/download-80.cgi
	Postman - v7.33.1 (for testing post)
		https://www.postman.com/

Coding Challenge for Software Engineer Applicants:
1.	Create a REST service with a single endpoint that accepts a json message 
	with two fields.."id" and "message". (example: { "id": "123", "message": "hello world" })
2.	The endpoint should return a json document with a single field "count" that contains the total number of words 
	contained in all the messages received to that point.
	a.	For example, if the first message contains 3 words it would respond with count = 3. 
		If the next message contains 5 words it would respond with count = 8.
3.	The service should ignore messages with duplicate ids. (i.e. ids that have already been processed)
4.	Use the programming language of your choice.
5.	Upload all code to a public github repo with a readme that explains how to build and run the project


Install Eclipse
Install TomCat
Install PostMan (requires account) or use another program that can send a HTTP POST
Open Project in Eclipse

In Eclipse - go to Window tab -> Preferences
Select Server -> Runtime Environment and Add Apache Tomcat

In TomCat Server Tab
On Overview - assign HTTP port to 8080 and Admin port to 8005 (if ports are not open on your system - may have to find and turn off app using them)
Add web module to server /LifeWay_REST_Service
Start Server

Right Click on LifeWay Rest Service and select Run As
Run on Apache Tomcat Server

Start Postman application
Create a  PUT to http://localhost:8080/LifeWay_REST_Service/rest/main
Setup the Headers tab to:
Key: Content-Type 
Value: application/json

Setup body tab to:
{ "id": "123", "message": "hello world" }

Click send 
adjust message / id and send again
watch for responses in lower panel